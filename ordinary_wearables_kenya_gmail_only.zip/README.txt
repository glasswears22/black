ORDINARY WEARABLES KENYA RENTAL WEBSITE CONCEPT

Open index.html in a browser to preview the responsive website.

Includes:
- Kenya-focused copy and KSh 1,000/day proposed base rate
- Confidence self-check questionnaire with practical tips
- Rental form with date selection and optional add-on requests
- Gmail-only email validation: only addresses ending in @gmail.com are accepted by the front-end form
- Mobile responsive design

Important:
- Gmail restriction in this prototype is client-side validation. A production site must also enforce this rule on its server/API, because browser-only checks can be bypassed.
- The confidence check is a self-reflection tool, not a validated psychological test.
- Confirm whether KSh 1,000/day applies to each product or the full bundle.
- Add-on prices are intentionally not invented; confirm them before checkout.
- The form does not submit bookings or process payments.
- Confirm permission to use the Ordinary Wearables name, logo and product images before launch.
